import React from 'react'

const Error = () => {
  return (
    <div className="vh-100">
      <div className="container h-100 d-flex justify-content-center align-items-center">
        <h1 className="display-1">Opps!! Wrong URL</h1>
      </div>
    </div>
  )
}

export default Error
